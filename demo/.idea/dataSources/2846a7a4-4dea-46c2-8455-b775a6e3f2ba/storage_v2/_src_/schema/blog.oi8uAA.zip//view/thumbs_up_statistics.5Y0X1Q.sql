create view thumbs_up_statistics as
select `tp`.`blog_id`                                        AS `blog_id`,
       `b`.`title`                                           AS `title`,
       `b`.`uid`                                             AS `uid`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 6 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `seven_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 5 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `six_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 4 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `five_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 3 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `four_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 2 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `three_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') = (curdate() - interval 1 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `two_day`,
       ifnull((select count(0)
               from `blog`.`thumbs_up` `t`
               where ((date_format(`t`.`create_time`, '%y-%m-%d') > (curdate() - interval 1 day)) and
                      (`t`.`blog_id` = `tp`.`blog_id`))), 0) AS `one_day`
from (`blog`.`thumbs_up` `tp`
         join `blog`.`blog` `b`)
where (`b`.`blog_id` = `tp`.`blog_id`)
group by `tp`.`blog_id`;

-- comment on column thumbs_up_statistics.title not supported: 标题

