create view blog_views as
select `v`.`blog_id` AS `blog_id`, `b`.`title` AS `title`, `v`.`create_time` AS `create_time`, `v`.`ip` AS `ip`
from (`blog`.`views` `v`
         join `blog`.`blog` `b`)
where (`b`.`blog_id` = `v`.`blog_id`);

-- comment on column blog_views.blog_id not supported: 访问的博客id

-- comment on column blog_views.title not supported: 标题

-- comment on column blog_views.create_time not supported: 访问的时间

-- comment on column blog_views.ip not supported: 访问者的ip

