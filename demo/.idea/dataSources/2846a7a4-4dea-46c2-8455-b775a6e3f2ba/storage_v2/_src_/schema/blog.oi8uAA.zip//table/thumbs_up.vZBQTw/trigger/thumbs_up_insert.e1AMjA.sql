create definer = root@localhost trigger thumbs_up_insert
    after insert
    on thumbs_up
    for each row
BEGIN
UPDATE blog as b SET b.thumbs =b.thumbs+1   WHERE b.blog_id= new.blog_id ;
END;

