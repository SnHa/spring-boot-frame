create view views_statistics as
select `vp`.`blog_id`                                        AS `blog_id`,
       `b`.`title`                                           AS `title`,
       `b`.`uid`                                             AS `uid`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 6 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `seven_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 5 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `six_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 4 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `five_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 3 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `four_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 2 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `three_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') = (curdate() - interval 1 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `two_day`,
       ifnull((select count(0)
               from `blog`.`views` `v`
               where ((date_format(`v`.`create_time`, '%y-%m-%d') > (curdate() - interval 1 day)) and
                      (`v`.`blog_id` = `vp`.`blog_id`))), 0) AS `one_day`
from (`blog`.`views` `vp`
         join `blog`.`blog` `b`)
where (`b`.`blog_id` = `vp`.`blog_id`)
group by `vp`.`blog_id`;

-- comment on column views_statistics.blog_id not supported: 访问的博客id

-- comment on column views_statistics.title not supported: 标题

