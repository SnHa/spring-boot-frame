create definer = root@localhost trigger thumbs_up_delete
    after delete
    on thumbs_up
    for each row
BEGIN
UPDATE blog as b SET b.thumbs = b.thumbs - 1   WHERE b.blog_id= old.blog_id  ;
END;

